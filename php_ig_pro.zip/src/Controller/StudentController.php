<?php
namespace Ig\IgPro\Controller;

use Ig\IgPro\Model\Student;

class StudentController {
    public function index() {
        // Handle the creation of a student
        // Load the view for creating a student
        require __DIR__ . '/../View/students/create_student.php';
    }

    public function create() {
        // Handle the submission of a new student
        // Create a new Student object and save it to the database
        $student = new Student();
        $student->setName($_POST['name']);
        $student->setAge($_POST['age']);
        $student->setGrade($_POST['grade']);
    }
}
