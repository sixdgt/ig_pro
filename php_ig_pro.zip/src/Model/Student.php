<?php
require_once __DIR__ . '/../../config/Database.php';

class Student {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }

    public function insert($name, $email) {
        $query = "INSERT INTO students (name, email) VALUES (:name, :email)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);

        return $stmt->execute();
    }
}
