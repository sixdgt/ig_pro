<?php
require_once 'vendor/autoload.php';

use Ig\IgPro\Controller\StudentController;

$uri = $_SERVER['REQUEST_URI'];

if ($uri === '/') {
    $std = new StudentController();
    $std->index();
}